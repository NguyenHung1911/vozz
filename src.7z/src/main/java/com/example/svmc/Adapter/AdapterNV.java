package com.example.svmc.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.svmc.R;
import com.example.svmc.SqliteHelper;
import com.example.svmc.fragment.AllFragment;
import com.example.svmc.fragment.TodayFragment;
import com.example.svmc.model.NhiemVu;

import java.util.ArrayList;

public class AdapterNV extends RecyclerView.Adapter<AdapterNV.HomeViewHolder>{
    private ArrayList<NhiemVu> list;
    private IteamListener iteamListener;

    public void setList(ArrayList<NhiemVu> list) {
        this.list = list;
        notifyDataSetChanged();
    }


    public void setIteamListener(IteamListener iteamListener) {
        this.iteamListener = iteamListener;
    }

    public NhiemVu getIteam(int pos) {
        return list.get(pos);
    }

    @NonNull
    @Override
    public HomeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.iteam, parent, false);
        return new HomeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HomeViewHolder holder, int position) {
        NhiemVu it = list.get(position);
        holder.nameNV.setText(it.getName());
        holder.dateNV.setText(it.getDate());
        holder.time.setText(it.getTime());

        if(it.getTrangThai() == 0) {
            holder.cb.setChecked(false);
            holder.cb.setEnabled(true);
        }
        else {
            holder.cb.setChecked(true);
            holder.cb.setEnabled(false);
        }

        holder.cb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                it.setTrangThai(1);
                list.set(holder.getAdapterPosition(), it);
                SqliteHelper sql = new SqliteHelper(view.getContext());
                sql.update(it);
                notifyDataSetChanged();

            }
        });

        holder.btnre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                list.remove(it);
                SqliteHelper sql = new SqliteHelper(view.getContext());
                sql.delete(it);
                notifyDataSetChanged();
                AllFragment.updateUI();
                TodayFragment.updateUI();
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class HomeViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView nameNV, dateNV, time;
        private CheckBox cb;
        private Button btnre;

        public HomeViewHolder(@NonNull View view) {
            super(view);

            nameNV = view.findViewById(R.id.nameNv);
            dateNV = view.findViewById(R.id.dateNV);
            time = view.findViewById(R.id.timeNV);
            cb = view.findViewById(R.id.cbtrangThai);
            btnre = view.findViewById(R.id.btnremoveNv);

        }

        @Override
        public void onClick(View view) {
            if(iteamListener != null) {
                iteamListener.onIteamClick(view, getAdapterPosition());
            }
        }
    }

    public interface IteamListener {
        void onIteamClick(View view, int pos);
    }
}
