package com.example.svmc.Adapter;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.svmc.fragment.All;
import com.example.svmc.fragment.Today;
import com.example.svmc.fragment.History;

public class AdapterViewPager extends FragmentPagerAdapter {
    private int pageNumber;
    public AdapterViewPager(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);
        this.pageNumber = behavior;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new Today();
            case 1:
                return new All();
            case 2:
                return new History();
        }
        return null;
    }

    @Override
    public int getCount() {
        return this.pageNumber;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return "Today";
            case 1:
                return "all";
            case 2:
                return "history";
        }
        return null;
    }
}
