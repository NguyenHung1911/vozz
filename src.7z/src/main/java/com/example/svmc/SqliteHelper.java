package com.example.svmc;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.svmc.model.NhiemVu;

import java.util.ArrayList;

public class SqliteHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "NHIEMVU.db";
    private static final int DATABASE_VERSION = 1;

    public SqliteHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String creatDB = "CREATE TABLE nv(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,date TEXT, " +
                "time TEXT,content TEXT,TrangThai INTEGER)";

        db.execSQL(creatDB);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
    }

    public ArrayList<NhiemVu> getAll() {
        ArrayList<NhiemVu> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String order = "time";
        Cursor rs = db.query("nv", null, null, null, null, null, order);
        while (rs != null && rs.moveToNext()) {
            int id = rs.getInt(0);
            String name = rs.getString(1);
            String date = rs.getString(2);
            String time = rs.getString(3);
            String content = rs.getString(4);
            int trangThai = rs.getInt(5);
            list.add(new NhiemVu(id, name, date, time, content, trangThai));
        }
        return list;
    }

    public ArrayList<NhiemVu> getAllToday(String today) {
        ArrayList<NhiemVu> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String order = "time";
        Cursor rs = db.query("nv", null, null, null, null, null, order);
        while (rs != null && rs.moveToNext()) {
            int id = rs.getInt(0);
            String name = rs.getString(1);
            String date = rs.getString(2);
            String time = rs.getString(3);
            String content = rs.getString(4);
            int trangThai = rs.getInt(5);
            if(date.equals(today)) {
                list.add(new NhiemVu(id, name, date, time, content, trangThai));
            }
        }
        return list;
    }

    public long add(NhiemVu item) {
        ContentValues content = new ContentValues();
        content.put("name", item.getName());
        content.put("date", item.getDate());
        content.put("time", item.getTime());
        content.put("content", item.getContent());
        content.put("trangThai", item.getTrangThai());

        SQLiteDatabase sql = getWritableDatabase();
        return sql.insert("nv", null, content);
    }

    public int update(NhiemVu item) {
        ContentValues content = new ContentValues();
        content.put("name", item.getName());
        content.put("date", item.getDate());
        content.put("time", item.getTime());
        content.put("content", item.getContent());
        content.put("trangThai", item.getTrangThai());

        String whereClause = "id=?";
        String[] whereArgs = {String.valueOf(item.getId())};
        SQLiteDatabase sql = getWritableDatabase();
        return sql.update("nv", content, whereClause, whereArgs);
    }

    public int delete(NhiemVu item) {
        String whereClause = "id=?";
        String[] whereArgs = {String.valueOf(item.getId())};

        SQLiteDatabase sql = getWritableDatabase();
        return sql.delete("nv", whereClause, whereArgs);
    }
}
