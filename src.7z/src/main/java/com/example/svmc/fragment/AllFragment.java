package com.example.svmc.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.svmc.Adapter.AdapterNV;
import com.example.svmc.AddActivity;
import com.example.svmc.MainActivity;
import com.example.svmc.R;
import com.example.svmc.SqliteHelper;
import com.example.svmc.UpdateActivity;
import com.example.svmc.model.NhiemVu;

import java.util.ArrayList;

public class AllFragment extends Fragment implements AdapterNV.IteamListener {
    private static AdapterNV adapter;
    private static SqliteHelper db;
    private RecyclerView recycler;
    private static ArrayList<NhiemVu> list;
    private static TextView tv, tv_name;
    private static Button btn_search;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_all, container, false);
        tv = view.findViewById(R.id.soNv);

        recycler = view.findViewById(R.id.recycleViewls);
        db = new SqliteHelper(getContext());
        adapter = new AdapterNV();
        list = db.getAll();


        tv.setText("so nhiem vu: " + list.size());
        adapter.setList(list);
        LinearLayoutManager manager = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false);
        recycler.setLayoutManager(manager);
        recycler.setHasFixedSize(true);
        recycler.setAdapter(adapter);
        adapter.setIteamListener(this);

        tv_name = view.findViewById(R.id.all_nameNv);
        btn_search = view.findViewById(R.id.all_btnsearch);
        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = tv_name.getText().toString();
                

            }
        });

        return view;
    }

    @Override
    public void onIteamClick(View view, int pos) {
        //Intent intent = new Intent(AllFragment.this, UpdateActivity.class);
        NhiemVu nv = list.get(pos);
    }

    public static void updateUI() {
        list.clear();
        list.addAll(db.getAll());
        tv.setText("so nhiem vu: " + list.size());
        adapter.notifyDataSetChanged();
    }
}
