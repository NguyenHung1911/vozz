package com.example.svmc.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.svmc.Adapter.AdapterNV;
import com.example.svmc.R;
import com.example.svmc.SqliteHelper;
import com.example.svmc.model.NhiemVu;

import java.util.ArrayList;
import java.util.Calendar;

public class TodayFragment extends Fragment {
    private static AdapterNV adapter;
    private static SqliteHelper db;
    private RecyclerView recycler;
    private static ArrayList<NhiemVu> list;
    private static TextView tv;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_today, container, false);
        tv = view.findViewById(R.id.soNvToDay);

        recycler = view.findViewById(R.id.recycleViewToday);
        db = new SqliteHelper(getContext());
        adapter = new AdapterNV();

        String today = whatToday();
        list = db.getAllToday(today);

        tv.setText("so nhiem vu: " + list.size());
        adapter.setList(list);
        LinearLayoutManager manager = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false);
        recycler.setLayoutManager(manager);
        recycler.setHasFixedSize(true);
        recycler.setAdapter(adapter);

        return view;
    }

    public static void updateUI() {
        list.clear();
        String today = whatToday();
        list.addAll(db.getAllToday(today));
        tv.setText("so nhiem vu: " + list.size());
        adapter.notifyDataSetChanged();

    }

    public static String whatToday() {
        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH) + 1;
        int year = calendar.get(Calendar.YEAR);
        String today = day + "/" + month + "/" + year;
        return today;
    }
}
