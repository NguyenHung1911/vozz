package com.example.svmc.model;

import java.io.Serializable;

public class NhiemVu implements Serializable {
    private int id;
    private String name, date, time, content;
    private int trangThai;


    public NhiemVu(int id, String name, String date, String time, String content, int trangThai) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.time = time;
        this.content = content;
        this.trangThai = trangThai;
    }

    public NhiemVu(String name, String date, String time, String content, int trangThai) {
        this.name = name;
        this.date = date;
        this.time = time;
        this.content = content;
        this.trangThai = trangThai;
    }

    public NhiemVu(String name, String date, String time, String content) {
        this.name = name;
        this.date = date;
        this.time = time;
        this.content = content;
        this.trangThai = 0;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }
}
